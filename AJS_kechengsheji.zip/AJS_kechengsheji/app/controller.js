// 添加控制器
var app=angular.module("myapp",[]);
app.controller("mainctrl",function($scope){
	$scope.person=[
		{"name":"别无所求","img":"images/a0.jpg"},
		{"name":"小鱼儿","img":"images/a9.jpg"},
		{"name":"大张李","img":"images/a5.jpg"},
		{"name":"我是黄小明","img":"images/a3.jpg"},
		{"name":"帕金森","img":"images/a6.jpg"},
		{"name":"请叫我大帅柯","img":"images/a4.jpg"},
		{"name":"月亮的影子","img":"images/a2.jpg"},
	];
	$scope.zan=25;
	$scope.fan=289;
	$scope.banner=['我的文章','最新动态','社区情报','好友留言','寻求帮助'];
	$scope.fans=[
		{"name":"小王","img":"images/a1.jpg","work":"设计师，博客","num":6},
		{"name":"月亮的影子","img":"images/a2.jpg","work":"作家，杂志编辑","num":3},
		{"name":"我是黄小明","img":"images/a3.jpg","work":"艺术总监，电影剪辑","num":21},
		{"name":"请叫我大帅柯","img":"images/a4.jpg","work":"音乐家，运动员","num":20}
	];
});

