// ����ļ�
var app=angular.module("myapp",[]);
app.controller("mainctrl",function($scope){
	$scope.user=0;
});