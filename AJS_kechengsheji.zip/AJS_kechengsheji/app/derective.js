// ����ָ��
app.directive('showmore', function (){
    return {
        restrict: 'E',
        template:'<div class="{{show?\'more2\':\'more\'}}">' +
        '<a href="javascript:;" ng-click="show=!show">more-></a>' +
        '<span ng-transclude></span></div>',
        transclude: true
    };
});